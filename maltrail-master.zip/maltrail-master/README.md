# maltrail
Dockerized maltrail for use in T-Pot
