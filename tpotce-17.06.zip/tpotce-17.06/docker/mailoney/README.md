[![](https://images.microbadger.com/badges/version/dtagdevsec/mailoney:1706.svg)](https://microbadger.com/images/dtagdevsec/mailoney:1706 "Get your own version badge on microbadger.com") [![](https://images.microbadger.com/badges/image/dtagdevsec/mailoney:1706.svg)](https://microbadger.com/images/dtagdevsec/mailoney:1706 "Get your own image badge on microbadger.com")

# mailoney
Dockerized mailoney for use in T-Pot
