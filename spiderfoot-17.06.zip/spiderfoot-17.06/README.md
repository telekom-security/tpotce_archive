[![](https://images.microbadger.com/badges/version/dtagdevsec/spiderfoot:1706.svg)](https://microbadger.com/images/dtagdevsec/spiderfoot:1706 "Get your own version badge on microbadger.com") [![](https://images.microbadger.com/badges/image/dtagdevsec/spiderfoot:1706.svg)](https://microbadger.com/images/dtagdevsec/spiderfoot:1706 "Get your own image badge on microbadger.com")

# spiderfoot
Dockerized Spiderfoot for use in T-Pot
